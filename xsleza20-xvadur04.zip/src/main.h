/**
 * @file main.h
 * @brief main header file
 * @author Martin Vadura, Alexandra Slezakova
 */
#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include "View/MainWindow.h"

#endif // MAIN_H
